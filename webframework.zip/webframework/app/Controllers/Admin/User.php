<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;

class User extends BaseController
{

    public function index()
    {
        $userModel = new UserModel();
        $data =
            [
                'nama' => "Administrator",
                'link' => "user",
                'list' => $userModel->FindAll(),
            ];
        return view('admin/user/user', $data);
    }

    public function detail($username)
    {
        $userModel = new UserModel();
        $data =
            [
                'nama' => "Administrator",
                'link' => "user",
                'item' => $userModel->where(['username' => $username])->first(),
            ];
        return view('admin/user/detail', $data);
    }

    public function create()
    {
        $data =
            [
                'nama' => "Administrator",
                'link' => "user"
            ];
        return view('admin/user/form', $data);
    }

    public function insert()
    {
        $userModel = new UserModel();
        $nama = $this->request->getVar('namadepan') . " " . $this->request->getVar('namabelakang');
        if ($this->request->getFile('avatar')->getName() != '') {
            $avatar = $this->request->getFile('avatar');
            $namaavatar = $avatar->getRandomName();
            $avatar->move(ROOTPATH . 'public/img/profil', $namaavatar);
        } else {
            $namaavatar = 'default.jpg';
        }

        $input = [
            'nama' => $nama,
            'alamat' => $this->request->getVar('alamat'),
            'tempat_lahir' => $this->request->getVar('tempatlahir'),
            'tanggal_lahir' => $this->request->getVar('tanggallahir'),
            'jenis_kelamin' => $this->request->getVar('jeniskelamin'),
            'telepon' => $this->request->getVar('telepon'),
            'email' => $this->request->getVar('email'),
            'username' => $this->request->getVar('username'),
            'password' => md5($this->request->getVar('password')),
            'avatar' => $namaavatar
        ];
        $userModel->save($input);

        session()->setFlashdata('label', 'Data anggota berhasil ditambahkan');
        return redirect()->to('/admin/user');
    }

    public function getdata()
    {
        if ($this->request->isAjax()) {
            $userModel = new UserModel();
            $data = [
                'list' => $userModel->findAll()
            ];

            $hasil = [
                'data' => view('admin/user/list', $data)
            ];
            echo json_encode($hasil);
        } else {
            exit('Data tidak dapat diload');
        }
    }

    public function getform()
    {
        if ($this->request->isAjax()) {
            $hasil = [
                'data' => view('admin/user/tambah')
            ];
            echo json_encode($hasil);
        } else {
            exit('Data tidak dapat diload');
        }
    }

    public function insertv2()
    {
        if ($this->request->isAJAX()) {

            $validasi = \Config\Services::validation();
            $valid = $this->validate([
                'namadepan' => [
                    'label' => 'Nama Depan',
                    'rules' => 'required',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong'
                    ]
                ],
                'alamat' => [
                    'label' => 'Alamat',
                    'rules' => 'required',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong'
                    ]
                ],
                'tempatlahir' => [
                    'label' => 'Tempat Lahir',
                    'rules' => 'required',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong'
                    ]
                ],
                'tanggallahir' => [
                    'label' => 'Tanggal Lahir',
                    'rules' => 'required',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong'
                    ]
                ],
                'telepon' => [
                    'label' => 'Telepon',
                    'rules' => 'required|integer',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong',
                        'integer' => '{field} harus diisi angka'
                    ]
                ],
                'email' => [
                    'label' => 'Email',
                    'rules' => 'required|is_unique[users.email]',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong',
                        'is_unique' => '{field} ini sudah digunakan'
                    ]
                ],
                'username' => [
                    'label' => 'Username',
                    'rules' => 'required|is_unique[users.username]',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong',
                        'is_unique' => '{field} ini sudah digunakan'
                    ]
                ],
                'password' => [
                    'label' => 'Password',
                    'rules' => 'required|exact_length[8]',
                    'errors' => [
                        'required' => '{field} tidak boleh kosong',
                        'exact_length' => '{field} wajib diisi 8 karakter'
                    ]
                ]
            ]);
            if (!$valid) {
                $pesan = [
                    'error' => [
                        'namadepan' => $validasi->getError('namadepan'),
                        'alamat' => $validasi->getError('alamat'),
                        'tempatlahir' => $validasi->getError('tempatlahir'),
                        'tanggallahir' => $validasi->getError('tanggallahir'),
                        'telepon' => $validasi->getError('telepon'),
                        'email' => $validasi->getError('email'),
                        'username' => $validasi->getError('username'),
                        'password' => $validasi->getError('password')
                    ]
                ];
                echo json_encode($pesan);
            } else {
                $userModel = new UserModel();
                $nama = $this->request->getVar('namadepan') . " " . $this->request->getVar('namabelakang');
                if ($this->request->getFile('avatar')->getName() != '') {
                    $avatar = $this->request->getFile('avatar');
                    $namaavatar = $avatar->getRandomName();
                    $avatar->move(ROOTPATH . 'public/img/profil', $namaavatar);
                } else {
                    $namaavatar = 'default.jpg';
                }
                $input = [
                    'nama' => $nama,
                    'alamat' => $this->request->getVar('alamat'),
                    'tempat_lahir' => $this->request->getVar('tempatlahir'),
                    'tanggal_lahir' => $this->request->getVar('tanggallahir'),
                    'jenis_kelamin' => $this->request->getVar('jeniskelamin'),
                    'telepon' => $this->request->getVar('telepon'),
                    'email' => $this->request->getVar('email'),
                    'username' => $this->request->getVar('username'),
                    'password' => md5($this->request->getVar('password')),
                    'avatar' => $namaavatar
                ];
                $userModel->save($input);
                $pesan = [
                    'sukses' => 'Data anggota berhasil diinput'
                ];
                echo json_encode($pesan);
            }
        } else {
            exit('Request salah');
        }
    }
}
