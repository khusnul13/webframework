 <div class="modal fade" id="formmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-xl">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Tambah Data Anggota</h5>
                 <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
             </div>
             <div class="modal-body">

                 <form id="formnya" action="user/insertv2" method="post" enctype="multipart/form-data">
                     <?= csrf_field(); ?>
                     <div class="row mb-4">
                         <div class="col">
                             <label class="form-label" for="nd">Nama depan</label>
                             <input type="text" id="nd" name="namadepan" class="form-control" />
                             <div class="invalid-feedback" id="errornd"></div>
                         </div>
                         <div class="col">
                             <label class="form-label" for="nb">Nama belakang</label>
                             <input type="text" id="nb" name="namabelakang" class="form-control" />

                         </div>
                     </div>

                     <div class="mb-4">
                         <label class="form-label" for="al">Alamat Rumah</label>
                         <textarea class="form-control" name="alamat" id="al" rows="4"></textarea>
                         <div class="invalid-feedback" id="erroral"></div>
                     </div>
                     <div class="row mb-4">

                         <div class="col">
                             <label class="form-label" for="tl">Tempat Lahir</label>
                             <input type="text" id="tl" name="tempatlahir" class="form-control" />
                             <div class="invalid-feedback" id="errortl"></div>
                         </div>
                         <div class="col">
                             <label class="form-label" for="tgl">Tanggal Lahir</label>
                             <input type="date" id="tgl" name="tanggallahir" class="form-control" />
                             <div class="invalid-feedback" id="errortgl"></div>

                         </div>
                     </div>
                     Jenis Kelamin : <div class="form-check form-check-inline mb-4 mx-3">
                         <input class="form-check-input" type="radio" name="jeniskelamin" id="flexRadioDefault1" value="laki-laki" checked />
                         <label class="form-check-label" for="flexRadioDefault1"> Laki-laki </label>
                     </div>

                     <div class="form-check form-check-inline mb-4 mx-3">
                         <input class="form-check-input" type="radio" name="jeniskelamin" id="flexRadioDefault2" value="perempuan" />
                         <label class="form-check-label" for="flexRadioDefault2"> Perempuan </label>
                     </div>
                     <div class=" mb-4">
                         <label class="form-label" for="tel">Telepon</label>
                         <input type="text" id="tel" name="telepon" class="form-control" />
                         <div class="invalid-feedback" id="errortel"></div>
                     </div>

                     <div class=" mb-4">
                         <label class="form-label" for="em">Email</label>
                         <input type="email" id="em" name="email" class="form-control" />
                         <div class="invalid-feedback" id="errorem"></div>
                     </div>

                     <div class=" mb-4">
                         <label class="form-label" for="un">Username</label>
                         <input type="text" id="un" name="username" class="form-control" />
                         <div class="invalid-feedback" id="errorun"></div>
                     </div>

                     <div class=" mb-4">
                         <label class="form-label" for="pass">Password</label>
                         <input type="password" id="pass" name="password" class="form-control" />
                         <div class="invalid-feedback" id="errorpass"></div>
                     </div>

                     Avatar : <div class="form-outline mb-4">
                         <input type="file" id="ava" name="avatar" class="form-control" />
                         <div class="invalid-feedback" id="errorava"></div>
                     </div>

                     <button type="submit" id="submit" class="btn btn-primary mb-4">Tambah Data</button>

                 </form>

             </div>
         </div>
     </div>
 </div>

 <script>
     $(document).ready(function() {
         $('#formnya').submit(function(e) {
             e.preventDefault();
             $.ajax({
                 type: $(this).attr('method'),
                 url: $(this).attr('action'),
                 data: new FormData(this),
                 processData: false,
                 contentType: false,
                 beforeSend: function() {
                     $('#submit').attr('disable', 'disabled');
                     $('#submit').html('<i class="fa fa-spin fa-spinner"></i>');
                 },
                 complete: function() {
                     $('#submit').removeAttr('disable');
                     $('#submit').html('Tambah Data');
                 },
                 success: function(response) {
                     var respon = JSON.parse(response);
                     if (respon.error) {
                         if (respon.error.namadepan) {
                             $('#nd').addClass('is-invalid');
                             $('#errornd').html(respon.error.namadepan);
                         } else {
                             $('#nd').removeClass('is-invalid');
                             $('#errornd').html('');
                         }

                         if (respon.error.alamat) {
                             $('#al').addClass('is-invalid');
                             $('#erroral').html(respon.error.alamat);
                         } else {
                             $('#al').removeClass('is-invalid');
                             $('#erroral').html('');
                         }

                         if (respon.error.tempatlahir) {
                             $('#tl').addClass('is-invalid');
                             $('#errortl').html(respon.error.tempatlahir);
                         } else {
                             $('#tl').removeClass('is-invalid');
                             $('#errortl').html('');
                         }

                         if (respon.error.tanggallahir) {
                             $('#tgl').addClass('is-invalid');
                             $('#errortgl').html(respon.error.tanggallahir);
                         } else {
                             $('#tgl').removeClass('is-invalid');
                             $('#errortgl').html('');
                         }

                         if (respon.error.telepon) {
                             $('#tel').addClass('is-invalid');
                             $('#errortel').html(respon.error.telepon);
                         } else {
                             $('#tel').removeClass('is-invalid');
                             $('#errortel').html('');
                         }

                         if (respon.error.email) {
                             $('#em').addClass('is-invalid');
                             $('#errorem').html(respon.error.email);
                         } else {
                             $('#em').removeClass('is-invalid');
                             $('#errorem').html('');
                         }

                         if (respon.error.username) {
                             $('#un').addClass('is-invalid');
                             $('#errorun').html(respon.error.username);
                         } else {
                             $('#un').removeClass('is-invalid');
                             $('#errorun').html('');
                         }

                         if (respon.error.password) {
                             $('#pass').addClass('is-invalid');
                             $('#errorpass').html(respon.error.password);
                         } else {
                             $('#pass').removeClass('is-invalid');
                             $('#errorpass').html('');
                         }

                         if (respon.error.avatar) {
                             $('#ava').addClass('is-invalid');
                             $('#errorava').html(respon.error.avatar);
                         } else {
                             $('#ava').removeClass('is-invalid');
                             $('#errorava').html('');
                         }

                     } else {
                         alert(respon.sukses);
                         $('#formmodal').modal('hide');
                         tampilkan();
                     }
                 },
                 error: function(xhr, ajaxOptions, thrownError) {
                     alert(xhr.status + "\n" + xhr.responseText + "\n" + thrownError);
                 }
             });

             return false;
         });
     });
 </script>